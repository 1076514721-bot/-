"use client";
import { useRef } from "react";

export default function WorkGallery({ images, title }: { images: string[]; title: string }) {
  const rail = useRef<HTMLDivElement>(null);
  const move = (direction: number) => rail.current?.scrollBy({ left: direction * (rail.current.clientWidth * .86), behavior: "smooth" });
  return <div className="gallery-shell">
    <div className="gallery-rail" ref={rail}>{images.map((src,i)=><figure className="gallery-slide" key={`${src}-${i}`}><img src={src} alt={`${title} ${i+1}`} /><figcaption>{String(i+1).padStart(2,"0")} / {String(images.length).padStart(2,"0")}</figcaption></figure>)}</div>
    {images.length>1&&<div className="gallery-controls"><button onClick={()=>move(-1)} aria-label="上一张">←</button><span>左右滑动浏览</span><button onClick={()=>move(1)} aria-label="下一张">→</button></div>}
  </div>;
}
