import { chatGPTSignInPath, chatGPTSignOutPath, getChatGPTUser } from "@/app/chatgpt-auth";
import { requireAdmin } from "@/lib/admin";
import { getPortfolio } from "@/lib/portfolio";
import Editor from "./editor";
export const dynamic = "force-dynamic";
export default async function AdminPage() { const user=await getChatGPTUser(); if(!user) return <main className="auth-card"><div><small>PORTFOLIO ADMIN</small><h1>作品集管理后台</h1><p>登录后可以修改个人介绍、案例文字、作品顺序和图片。保存后，公开链接会同步显示。</p><a className="primary-button" href={chatGPTSignInPath("/admin")} target="_top">使用 ChatGPT 登录</a><a className="text-link" href="/">返回公开作品集</a></div></main>; const auth=await requireAdmin(); if(!auth.ok) return <main className="auth-card"><div><h1>当前账号没有编辑权限</h1><p>请退出后，使用网站所有者的 ChatGPT 账号登录。</p><a className="primary-button" href={chatGPTSignOutPath("/admin")} target="_top">退出并重新登录</a></div></main>; return <Editor initial={await getPortfolio()} userName={user.displayName} signOut={chatGPTSignOutPath("/")} />; }
