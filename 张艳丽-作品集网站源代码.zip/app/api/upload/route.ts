import { env } from "cloudflare:workers";
import { NextResponse } from "next/server";
import { requireAdmin } from "@/lib/admin";

export async function POST(request: Request) {
  const auth = await requireAdmin();
  if (!auth.ok) return NextResponse.json({ error: "没有上传权限" }, { status: auth.status });
  const file = (await request.formData()).get("file");
  if (!(file instanceof File) || !file.type.startsWith("image/")) return NextResponse.json({ error: "请选择图片文件" }, { status: 400 });
  if (file.size > 15 * 1024 * 1024) return NextResponse.json({ error: "单张图片不能超过 15MB" }, { status: 400 });
  if (!env.BUCKET) return NextResponse.json({ error: "图片存储尚未配置" }, { status: 500 });
  const extension = file.name.split(".").pop()?.replace(/[^a-z0-9]/gi, "") || "jpg";
  const key = `portfolio/${crypto.randomUUID()}.${extension}`;
  await env.BUCKET.put(key, await file.arrayBuffer(), { httpMetadata: { contentType: file.type } });
  return NextResponse.json({ url: `/api/media/${key}` });
}
