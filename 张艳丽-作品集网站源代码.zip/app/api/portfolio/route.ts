import { NextResponse } from "next/server";
import { getDb } from "@/db";
import { portfolioContent } from "@/db/schema";
import { getPortfolio, type PortfolioData } from "@/lib/portfolio";
import { requireAdmin } from "@/lib/admin";

export const dynamic = "force-dynamic";

export async function GET() { return NextResponse.json(await getPortfolio()); }

export async function PUT(request: Request) {
  const auth = await requireAdmin();
  if (!auth.ok) return NextResponse.json({ error: auth.status === 401 ? "请先登录" : "当前账号没有编辑权限" }, { status: auth.status });
  const data = await request.json() as PortfolioData;
  if (!data?.name || !Array.isArray(data.works)) return NextResponse.json({ error: "内容格式不正确" }, { status: 400 });
  const now = new Date().toISOString();
  await getDb().insert(portfolioContent).values({ id: 1, content: JSON.stringify(data), updatedAt: now })
    .onConflictDoUpdate({ target: portfolioContent.id, set: { content: JSON.stringify(data), updatedAt: now } });
  return NextResponse.json({ ok: true, updatedAt: now });
}
