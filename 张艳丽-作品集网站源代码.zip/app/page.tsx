import { getPortfolio } from "@/lib/portfolio";
import WorkGallery from "@/components/work-gallery";
export const dynamic = "force-dynamic";

export default async function Home() {
  const p=await getPortfolio();
  return <main>
    <header className="site-nav"><a className="nav-brand" href="#top"><strong>{p.name}</strong><span>PORTFOLIO</span></a><nav aria-label="页面导航"><a href="#top">关于我</a><a href="#experience">经历</a><a href="#contents">目录</a><div className="nav-dropdown"><a href="#works">作品⌄</a><div>{p.works.map(w=><a href={`#${w.id}`} key={w.id}>{w.title}</a>)}</div></div><a href="#contact">联系</a></nav></header>
    <section className="hero hero-cinematic" id="top"><div className="hero-glow"/><div className="hero-ring"/><div className="hero-meta"><span>✦ ✦ ✦</span><span>2026 · SELECTED WORKS</span></div><div className="eyebrow">ART DIRECTION · BRAND VISUAL · MANAGEMENT</div><div className="display-title"><span>DESIGN</span><span>PORT<span>FOLIO</span></span></div><div className="hero-copy"><div><h1>{p.headline}</h1><p className="role">{p.role}</p></div><p className="bio">{p.bio}</p></div><div className="facts"><span>{p.teamSize}</span><a href={`mailto:${p.email}`}>{p.email}</a></div></section>
    <section className="experience" id="experience"><div className="experience-heading"><small>LEADERSHIP & EXPERIENCE</small><h2>经验与能力</h2><p>从设计执行走向创意决策与团队管理，让视觉系统持续服务于品牌目标。</p></div><div className="experience-list">{p.experiences.map((x,i)=><article key={i}><b>{String(i+1).padStart(2,"0")}</b><p>{x}</p><span>↗</span></article>)}</div></section>
    <section className="directory" id="contents"><header><div><small>LIST OF WORKS</small><h2>作品目录</h2></div><span>01—{String(p.works.length).padStart(2,"0")}</span></header><div className="directory-cards">{p.works.map((w,i)=><a className="directory-card" href={`#${w.id}`} key={w.id}><b>{String(i+1).padStart(2,"0")}</b><div><h3>{w.title}</h3><small>{w.en}</small></div><span>查看项目 ↗</span></a>)}</div></section>
    <section className="works" id="works">{p.works.map((w,i)=>{const images=w.images?.length?w.images:[w.image];return <article className="work" id={w.id} key={w.id}><header><span>{String(i+1).padStart(2,"0")}</span><div><small>{w.en}</small><h2>{w.title}</h2><p>{w.description}</p></div></header><WorkGallery images={images} title={w.title}/></article>})}</section>
    <footer id="contact"><div><strong>{p.name}</strong><span>{p.role}</span></div><a className="admin-link" href="/admin">编辑网站</a><a href="#top">返回顶部 ↑</a></footer>
  </main>;
}
