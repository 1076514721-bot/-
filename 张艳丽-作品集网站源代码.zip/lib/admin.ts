import { env } from "cloudflare:workers";
import { getChatGPTUser } from "@/app/chatgpt-auth";

export async function requireAdmin() {
  const user = await getChatGPTUser();
  if (!user) return { ok: false as const, status: 401, user: null };
  const allowed = env.ADMIN_EMAIL || "seedy@sites.test";
  if (user.email.toLowerCase() !== allowed.toLowerCase()) return { ok: false as const, status: 403, user };
  return { ok: true as const, status: 200, user };
}
