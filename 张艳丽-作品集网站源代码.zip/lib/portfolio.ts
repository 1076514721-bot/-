import { eq } from "drizzle-orm";
import { getDb } from "@/db";
import { portfolioContent } from "@/db/schema";

export type WorkItem = { id: string; title: string; en: string; description: string; image: string; images?: string[] };
export type PortfolioData = {
  name: string; role: string; headline: string; bio: string; email: string; teamSize: string;
  experiences: string[]; works: WorkItem[];
};

export const defaultPortfolio: PortfolioData = {
  name: "张艳丽",
  role: "美术指导 · 品牌视觉 · 团队管理",
  headline: "你好，我是张艳丽。",
  bio: "我专注于品牌视觉、平面设计与线上内容创意，也拥有从选题、创意方向到团队管理的完整经验。曾带领最多 7 人设计团队，负责任务分配、设计审核、绩效与招聘。我希望下一阶段进入品牌公司内部，承担设计负责人角色，让视觉真正服务于品牌长期增长。",
  email: "e972609823@qq.com",
  teamSize: "最多带领 7 人设计团队",
  experiences: [
    "线上内容：邀请函模板、海报、长页与 H5，覆盖商务、教培、婚礼、宝宝宴、寿宴及促销等场景。",
    "品牌甲方：担任设计组长，负责品牌画册、月度促销活动与品牌活动视觉。",
    "设计公司：完成多类线下活动与展会的整体平面视觉及落地执行。",
  ],
  works: [
    { id: "posters", title: "线上主题海报", en: "ONLINE POSTERS", description: "以高频、多场景的线上传播需求为核心，建立兼顾效率与差异化的视觉表达。", image: "/assets/complete-posters.webp" },
    { id: "h5", title: "邀请函与 H5", en: "INVITATIONS & H5", description: "覆盖商务、教培、婚礼、满月、周岁与寿宴等场景，形成完整内容与视觉模板体系。", image: "/assets/complete-h5.webp" },
    { id: "brand", title: "品牌活动视觉", en: "BRAND CAMPAIGNS", description: "围绕品牌目标制定创意方向，并推动线上线下物料统一落地。", image: "/assets/complete-brand.webp" },
    { id: "brochure", title: "品牌画册", en: "BRAND BROCHURES", description: "梳理品牌信息层级，以系统化版式呈现产品、服务与品牌价值。", image: "/assets/complete-brochures.webp" },
    { id: "events", title: "活动视觉落地", en: "EVENT VISUALS", description: "从主视觉延展到现场物料，兼顾传播效果、执行效率与落地质量。", image: "/assets/complete-events.webp" },
    { id: "exhibitions", title: "展会平面设计", en: "EXHIBITION DESIGN", description: "根据空间与参观动线组织信息，使展会视觉保持识别度和整体性。", image: "/assets/complete-exhibitions.webp" },
  ],
};

export async function getPortfolio(): Promise<PortfolioData> {
  try {
    const db = getDb();
    const row = await db.select().from(portfolioContent).where(eq(portfolioContent.id, 1)).get();
    return row ? JSON.parse(row.content) as PortfolioData : defaultPortfolio;
  } catch { return defaultPortfolio; }
}
